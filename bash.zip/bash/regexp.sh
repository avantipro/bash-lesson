#! /bin/bash

A="This is regexp searching"
if [[ "$A" =~ T.*exp.*ing ]]; then echo "Match"; fi

echo '----------------------'

A='arg1 arg2 arg3';[ "$A" == 'x' ]
echo $?
