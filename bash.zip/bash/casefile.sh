#! /bin/bash

A='document_access_security.doc'

case "$A" in
*[0-9]*) echo 'digits';;
*[a-z]*) echo 'a-z' ;;&
*[_.]*) echo 'symbols';;
esac
