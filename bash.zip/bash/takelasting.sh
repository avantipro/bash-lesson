#! /bin/bash

while
read A
do
echo $A
done </etc/group
