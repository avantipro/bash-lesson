#! /bin/bash

A=1

case "$A" in
1) echo 'One';;
2) echo 'Two';;
*) echo 'Not';;
esac
