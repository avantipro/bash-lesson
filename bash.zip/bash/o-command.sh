#! /bin/bash

# -e  - cуперопции

echo '------------------'
echo "echo 1\n2"
echo '1\n2'
echo '------------------'
echo "echo -e 1\n2"
echo -e '1\n2'
echo '------------------'

# как выполнить
word='root'
val="grep '$word' /etc/passwd >/dev/null"
echo $?

echo '----------------------------'
echo '-----check_content_file-----'

# отправляем значение в файл
echo -e '1\n2\n3' -f > file.txt
cat file.txt

echo '----------------------------'
echo '----------df - command------'
df


echo '----------------------------'
echo '-'
echo '----------check-lang--------'
echo $LANG

echo '-'
echo '----------------------------'
echo '----change lang for one command-----'
echo '-'
LANG=en_EN.UTF-8 df
