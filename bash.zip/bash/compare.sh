#! /bin/bash

A=5; if [ "$A" == 5 ]; then echo 5; fi

echo '------------------------------'

D=4; if [ "$D" == 5 ]; then echo "!="; elif [ "$D" == '4' ];then echo '='; fi
